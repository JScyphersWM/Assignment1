/**
 * Kassen f�r die Mehrsprachenunterst�tzung.
 * @author Alexander Herzog
 */
package language;