/**
 * Enth�lt verschiedene Logger, die w�hrend der Simulation zur Aufzeichnung von Logging-Daten verwendet werden k�nnen.
 * @author Alexander Herzog
 */
package simcore.logging;