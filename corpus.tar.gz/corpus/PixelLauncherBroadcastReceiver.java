package dev.dworks.apps.alauncher.companion;

public class PixelLauncherBroadcastReceiver extends Forwarder {
}
